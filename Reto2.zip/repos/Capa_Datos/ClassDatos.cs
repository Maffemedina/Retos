﻿using Capa_entidad;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Capa_entidad;


namespace Capa_Datos
{
    public class ClassDatos
    {
        SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["sql"].ConnectionString);

        public DataTable D_Listar_libros()
        {
            SqlCommand cmd = new SqlCommand("listar_libros", cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable D_buscar_libros(ClassEntidad entidad)
        {
            SqlCommand cmd = new SqlCommand("buscar_libros", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@titulo", entidad.titulo);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public String D_mantenimiento_libros(ClassEntidad entidad)
        {
            String accion = "";
            SqlCommand cmd = new SqlCommand("mantenimiento_libros", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@codigo", entidad.codigo);
            cmd.Parameters.AddWithValue("@titulo", entidad.titulo);
            cmd.Parameters.AddWithValue("@autor", entidad.autor);
            cmd.Parameters.AddWithValue("@editorial", entidad.editorial);
            cmd.Parameters.AddWithValue("@precio", entidad.precio);
            cmd.Parameters.AddWithValue("@cantidad", entidad.cantidad);
            cmd.Parameters.Add("@accion", SqlDbType.VarChar, 50).Value = entidad.accion;
            cmd.Parameters["@accion"].Direction = ParameterDirection.InputOutput;
            if (cn.State == ConnectionState.Open) cn.Close();
            cn.Open();
            cmd.ExecuteNonQuery();
            accion = cmd.Parameters["@accion"].Value.ToString();
            cn.Close();
            return accion;
        }
    }

}
