﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using Capa_entidad;
using Capa_Datos;

namespace Capa_negocio
{
    public class ClassNegocio
    {
        ClassDatos datos = new ClassDatos();

        public DataTable N_listar_libros()
        {
            return datos.D_Listar_libros();
        }

        public DataTable N_buscar_libros(ClassEntidad entidad)
        {
            return datos.D_buscar_libros(entidad);
        }

        public String N_mantenimiento_libros(ClassEntidad entidad)
        {
            return datos.D_mantenimiento_libros(entidad);
        }
    }

}
